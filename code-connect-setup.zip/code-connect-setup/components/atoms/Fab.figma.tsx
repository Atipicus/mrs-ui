import figma from "@figma/code-connect";
import { Fab } from "./Fab";

/**
 * Code Connect mapping for Fab (Floating Action Button) component
 * Figma File: MRS - Material UI
 * Repository: https://github.com/mgomez-ext/mrs-ui/
 */
figma.connect(
  Fab,
  "https://www.figma.com/design/pWR8HIewAt87ZioeOSMoWM/MRS---Material-UI?node-id=11096-136260",
  {
    props: {
      variant: figma.enum("variant", {
        Circular: "circular",
        Extended: "extended",
      }),
      color: figma.enum("color", {
        Primary: "primary",
        Secondary: "secondary",
        Error: "error",
        Warning: "warning",
        Info: "info",
        Success: "success",
        Default: "default",
        Inherit: "inherit",
      }),
      size: figma.enum("size", {
        Small: "small",
        Medium: "medium",
        Large: "large",
      }),
      disabled: figma.boolean("disabled"),
    },
    example: (props) => (
      <Fab
        variant={props.variant}
        color={props.color}
        size={props.size}
        disabled={props.disabled}
      >
        {/* Icon or label */}
      </Fab>
    ),
  }
);
