import figma from "@figma/code-connect";
import { IconButton } from "./IconButton";

/**
 * Code Connect mapping for IconButton component
 * Figma File: MRS - Material UI
 * Repository: https://github.com/mgomez-ext/mrs-ui/
 */
figma.connect(
  IconButton,
  "https://www.figma.com/design/pWR8HIewAt87ZioeOSMoWM/MRS---Material-UI?node-id=11112-140597;9974-112159",
  {
    props: {
      color: figma.enum("color", {
        Primary: "primary",
        Secondary: "secondary",
        Error: "error",
        Warning: "warning",
        Info: "info",
        Success: "success",
        Default: "default",
        Inherit: "inherit",
      }),
      size: figma.enum("size", {
        Small: "small",
        Medium: "medium",
        Large: "large",
      }),
      disabled: figma.boolean("disabled"),
      edge: figma.enum("edge", {
        Start: "start",
        End: "end",
        False: false,
      }),
    },
    example: (props) => (
      <IconButton
        color={props.color}
        size={props.size}
        disabled={props.disabled}
        edge={props.edge}
      >
        {/* Icon */}
      </IconButton>
    ),
  }
);
