import figma from "@figma/code-connect";
import { Rating } from "./Rating";

/**
 * Code Connect mapping for Rating component
 * Figma File: MRS - Material UI
 * Repository: https://github.com/mgomez-ext/mrs-ui/
 */
figma.connect(
  Rating,
  "https://www.figma.com/design/pWR8HIewAt87ZioeOSMoWM/MRS---Material-UI?node-id=11095-136702",
  {
    props: {
      size: figma.enum("size", {
        Small: "small",
        Medium: "medium",
        Large: "large",
      }),
      disabled: figma.boolean("disabled"),
      readOnly: figma.boolean("readOnly"),
      precision: figma.enum("precision", {
        "0.5": 0.5,
        "1": 1,
      }),
      max: figma.enum("max", {
        "5": 5,
        "10": 10,
      }),
    },
    example: (props) => (
      <Rating
        size={props.size}
        disabled={props.disabled}
        readOnly={props.readOnly}
        precision={props.precision}
        max={props.max}
      />
    ),
  }
);
