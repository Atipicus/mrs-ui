import figma from "@figma/code-connect";
import { Card } from "./Card";

/**
 * Code Connect mapping for Card component
 * Figma File: MRS - Material UI
 * Repository: https://github.com/mgomez-ext/mrs-ui/
 */
figma.connect(
  Card,
  "https://www.figma.com/design/pWR8HIewAt87ZioeOSMoWM/MRS---Material-UI?node-id=11125-154834",
  {
    props: {
      variant: figma.enum("variant", {
        Elevation: "elevation",
        Outlined: "outlined",
      }),
      raised: figma.boolean("raised"),
    },
    example: (props) => (
      <Card
        variant={props.variant}
        raised={props.raised}
      >
        {/* CardHeader, CardContent, CardActions, CardMedia */}
      </Card>
    ),
  }
);

/**
 * CardHeader sub-component
 */
figma.connect(
  "CardHeader",
  "https://www.figma.com/design/pWR8HIewAt87ZioeOSMoWM/MRS---Material-UI?node-id=6640-51939",
  {
    props: {
      title: figma.string("title"),
      subheader: figma.string("subheader"),
      avatar: figma.boolean("avatar"),
      action: figma.boolean("action"),
    },
    example: (props) => (
      <CardHeader
        title={props.title}
        subheader={props.subheader}
        avatar={props.avatar ? <Avatar /> : undefined}
        action={props.action ? <IconButton /> : undefined}
      />
    ),
  }
);

/**
 * CardContent sub-component
 */
figma.connect(
  "CardContent",
  "https://www.figma.com/design/pWR8HIewAt87ZioeOSMoWM/MRS---Material-UI?node-id=6640-52022",
  {
    example: () => (
      <CardContent>
        {/* Content */}
      </CardContent>
    ),
  }
);

/**
 * CardActions sub-component
 */
figma.connect(
  "CardActions",
  "https://www.figma.com/design/pWR8HIewAt87ZioeOSMoWM/MRS---Material-UI?node-id=6676-48056",
  {
    props: {
      disableSpacing: figma.boolean("disableSpacing"),
    },
    example: (props) => (
      <CardActions disableSpacing={props.disableSpacing}>
        {/* Button or IconButton actions */}
      </CardActions>
    ),
  }
);
