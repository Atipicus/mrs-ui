import figma from "@figma/code-connect";
import { Snackbar } from "./Snackbar";

/**
 * Code Connect mapping for Snackbar component
 * Figma File: MRS - Material UI
 * Repository: https://github.com/mgomez-ext/mrs-ui/
 */
figma.connect(
  Snackbar,
  "https://www.figma.com/design/pWR8HIewAt87ZioeOSMoWM/MRS---Material-UI?node-id=11136-152888",
  {
    props: {
      anchorOrigin: figma.enum("position", {
        "Top-Left": { vertical: "top", horizontal: "left" },
        "Top-Center": { vertical: "top", horizontal: "center" },
        "Top-Right": { vertical: "top", horizontal: "right" },
        "Bottom-Left": { vertical: "bottom", horizontal: "left" },
        "Bottom-Center": { vertical: "bottom", horizontal: "center" },
        "Bottom-Right": { vertical: "bottom", horizontal: "right" },
      }),
      autoHideDuration: figma.enum("autoHide", {
        "3s": 3000,
        "6s": 6000,
        None: null,
      }),
      message: figma.string("message"),
    },
    example: (props) => (
      <Snackbar
        open={true}
        onClose={() => {}}
        anchorOrigin={props.anchorOrigin}
        autoHideDuration={props.autoHideDuration}
        message={props.message}
        action={
          <IconButton size="small" color="inherit" onClick={() => {}}>
            <CloseIcon fontSize="small" />
          </IconButton>
        }
      />
    ),
  }
);
