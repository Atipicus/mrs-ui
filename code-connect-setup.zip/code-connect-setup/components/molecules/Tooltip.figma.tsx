import figma from "@figma/code-connect";
import { Tooltip } from "./Tooltip";

/**
 * Code Connect mapping for Tooltip component
 * Figma File: MRS - Material UI
 * Repository: https://github.com/mgomez-ext/mrs-ui/
 */
figma.connect(
  Tooltip,
  "https://www.figma.com/design/pWR8HIewAt87ZioeOSMoWM/MRS---Material-UI?node-id=11102-139521",
  {
    props: {
      placement: figma.enum("placement", {
        Top: "top",
        Bottom: "bottom",
        Left: "left",
        Right: "right",
        "Top-Start": "top-start",
        "Top-End": "top-end",
        "Bottom-Start": "bottom-start",
        "Bottom-End": "bottom-end",
        "Left-Start": "left-start",
        "Left-End": "left-end",
        "Right-Start": "right-start",
        "Right-End": "right-end",
      }),
      arrow: figma.boolean("arrow"),
      title: figma.string("title"),
    },
    example: (props) => (
      <Tooltip
        title={props.title}
        placement={props.placement}
        arrow={props.arrow}
      >
        <Button>Hover me</Button>
      </Tooltip>
    ),
  }
);
