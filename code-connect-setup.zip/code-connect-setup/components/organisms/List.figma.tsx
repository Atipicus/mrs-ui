import figma from "@figma/code-connect";
import { List } from "./List";

/**
 * Code Connect mapping for List component
 * Figma File: MRS - Material UI
 * Repository: https://github.com/mgomez-ext/mrs-ui/
 */
figma.connect(
  List,
  "https://www.figma.com/design/pWR8HIewAt87ZioeOSMoWM/MRS---Material-UI?node-id=11102-138084",
  {
    props: {
      dense: figma.boolean("dense"),
      disablePadding: figma.boolean("disablePadding"),
    },
    example: (props) => (
      <List
        dense={props.dense}
        disablePadding={props.disablePadding}
      >
        <ListItem>
          <ListItemIcon><InboxIcon /></ListItemIcon>
          <ListItemText primary="Inbox" />
        </ListItem>
        <ListItem>
          <ListItemIcon><DraftsIcon /></ListItemIcon>
          <ListItemText primary="Drafts" />
        </ListItem>
      </List>
    ),
  }
);

/**
 * ListItem sub-component
 */
figma.connect(
  "ListItem",
  "https://www.figma.com/design/pWR8HIewAt87ZioeOSMoWM/MRS---Material-UI?node-id=11102-137981",
  {
    props: {
      alignItems: figma.enum("alignItems", {
        "Flex-Start": "flex-start",
        Center: "center",
      }),
      divider: figma.boolean("divider"),
      disableGutters: figma.boolean("disableGutters"),
      disablePadding: figma.boolean("disablePadding"),
      selected: figma.boolean("selected"),
    },
    example: (props) => (
      <ListItem
        alignItems={props.alignItems}
        divider={props.divider}
        disableGutters={props.disableGutters}
        disablePadding={props.disablePadding}
        selected={props.selected}
      >
        <ListItemText primary="List item" />
      </ListItem>
    ),
  }
);
